# How to apply this CI update (mobile / GitHub web editor friendly)

## 1. Add the workflow file
In your repo (GitHub web editor is fine):

1. Create the path `.github/workflows/ci.yml` if it doesn't exist.
2. Paste in the contents of `ci.yml` from this package.
3. If you already have a `.github/workflows/ci.yml`, replace it (or rename
   this one to `ci.yml` and delete the old workflow to avoid duplicate runs).

## 2. Make sure package-lock.json is committed and current
This workflow prefers `npm ci`, which needs an accurate, committed
`package-lock.json` at the repo root (workspaces monorepo root, not
per-package). If your lockfile is stale or missing:

```bash
npm install         # regenerates package-lock.json from package.json files
git add package-lock.json
```

If you don't have shell access right now (mobile-only), you can still
commit the workflow file as-is — the workflow's fallback logic
(`npm install` if no lockfile) will keep CI running, but `npm ci` is faster
and more reproducible once the lockfile is in place.

## 3. Commit message (conventional commits)
Use this commit message when you save the file(s):

```
ci: add automated dependency install & test workflow

- Add .github/workflows/ci.yml
- Runs npm ci (falls back to npm install) across all npm workspaces
- Adds lint, test, and build steps gated with --if-present
- Uploads coverage/test artifacts on every run
- Triggers on push/PR to main, master, and dev branches
```

## 4. Verify
- Push the commit (or open the PR).
- Go to the **Actions** tab in GitHub → you should see the "CI" workflow
  running.
- If a step fails because a script (lint/test/build) doesn't exist in a
  given workspace, that's fine — `--if-present` skips it silently instead
  of failing the build.

## 5. If the phantom `@proof-of-dev/chain-data-spec` dependency comes back
That error means some `package.json` in the workspaces still references a
package that isn't published or isn't a local workspace. Before re-running
CI:
1. Search all `package.json` files for `@proof-of-dev/chain-data-spec`.
2. Either point it to the local workspace path (if it's meant to be
   internal) or remove the reference if it's stale.
3. Regenerate the lockfile (`npm install`) and commit it.
