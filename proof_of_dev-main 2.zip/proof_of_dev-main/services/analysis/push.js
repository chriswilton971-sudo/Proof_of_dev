/**
 * ZeroMQ push socket — hot-path analysis queue.
 *
 * Implementation notes:
 * - zeromq is optional (moved to optionalDependencies). If zeromq is
 *   available we use the real Push socket. Otherwise we provide an
 *   in-process fallback that queues messages in memory so the API and
 *   worker can run in-process for demo/tests without a native lib.
 */

import { QUEUE_ENDPOINT } from "./config.js";

/** In-memory queue used by the fallback push implementation */
export const inMemoryQueue = [];

/** Internal singleton for the push transport (real or fallback) */
let _transport = null;
let _binding = null;

async function createZmqPush() {
  // Dynamic import so package is optional
  const mod = await import("zeromq");
  const { Push } = mod;
  const push = new Push();
  await push.bind(QUEUE_ENDPOINT);
  console.info(`[push] Zeromq bound on ${QUEUE_ENDPOINT}`);
  return {
    send: async (payload) => push.send(payload),
    close: () => push.close(),
    type: "zeromq",
  };
}

function createInMemoryPush() {
  console.warn(
    "[push] zeromq not available — using in-memory fallback queue. This is suitable for demo/testing only."
  );
  return {
    send: async (payload) => {
      // store payload and a timestamp
      inMemoryQueue.push({ payload, created_at: new Date() });
      return Promise.resolve();
    },
    close: () => {
      // no-op for in-memory
    },
    type: "inmemory",
  };
}

/**
 * Returns a transport with a send(payload) async function. Never throws —
 * always returns either the zeromq transport or the in-memory fallback.
 */
export async function getPush() {
  if (_transport) return _transport;
  if (_binding) return _binding;

  _binding = (async () => {
    try {
      const t = await createZmqPush();
      _transport = t;
      return t;
    } catch (err) {
      // If zeromq import or bind fails, fall back to in-memory transport.
      console.warn(`[push] zeromq unavailable or failed to bind: ${err.message}`);
      const t = createInMemoryPush();
      _transport = t;
      return t;
    } finally {
      _binding = null;
    }
  })();

  return _binding;
}

export function closePush() {
  if (_transport) {
    try {
      _transport.close();
      console.info("[push] Transport closed");
    } catch (err) {
      console.warn("[push] Error closing transport:", err.message);
    }
    _transport = null;
  }
}
