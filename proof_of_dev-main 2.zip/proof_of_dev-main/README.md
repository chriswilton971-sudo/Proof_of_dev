## Requirements

- Node.js >= 18 and npm (nvm recommended). The project uses modern Node features (global fetch, ESM modules) and Next.js 16 — use Node 18+.
- Optional: MongoDB (for persisted analysis results). If not available, the app can run in demo/mock mode (set MOCK_CHAIN_DATA=1 in .env.local).
- ZeroMQ native dependency: services/analysis depends on zeromq which may require system build tools / libzmq dev libraries on some platforms. On Ubuntu runners and local Linux, install:
  sudo apt-get update && sudo apt-get install -y libzmq3-dev build-essential pkg-config

## Quick run (demo mode)

1) cp .env.example .env.local
2) set MOCK_CHAIN_DATA=1 in .env.local (or export MOCK_CHAIN_DATA=1)
3) npm ci
4) npm run generate:scoring
5) npm run test:scoring
6) npm run dev
