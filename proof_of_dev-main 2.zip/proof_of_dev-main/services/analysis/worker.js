import { analyzeWallet, countUniqueInteractors } from "./tasks.js";
import { QUEUE_ENDPOINT, IN_MEMORY_JOB_POLL_INTERVAL_MS } from "./config.js";
import { ensureIndexes, saveJobResult, saveJobProgress } from "./db.js";
import { setEnrichmentHandler } from "./queues.js";
import { inMemoryQueue } from "./push.js";

/**
 * Worker process — supports both real ZeroMQ pull socket and an in-memory
 * queue fallback (for demo/tests when zeromq is not present).
 */

// Try to ensure indexes but don't crash if MongoDB is unavailable
ensureIndexes().then(() => {
  console.info("[worker] MongoDB ready");
}).catch(() => {
  // already warned inside ensureIndexes
});

// Register the enrichment handler (non-hot-path, in-process queue)
setEnrichmentHandler(countUniqueInteractors);
console.info("[worker] Enrichment handler registered");

let _pull = null;
let _running = true;

async function initZmqPull() {
  try {
    const mod = await import("zeromq");
    const { Pull } = mod;
    const pull = new Pull();
    await pull.connect(QUEUE_ENDPOINT);
    console.info(`[worker] Connected to queue on ${QUEUE_ENDPOINT} (zeromq)`);
    return { type: "zeromq", pull };
  } catch (err) {
    console.warn(`[worker] zeromq not available — using in-memory queue: ${err.message}`);
    return { type: "inmemory" };
  }
}

async function runZmqLoop(pull) {
  for await (const [raw] of pull) {
    await handleRawMessage(raw.toString());
  }
}

async function handleRawMessage(raw) {
  let job;
  try {
    job = JSON.parse(raw);
  } catch (err) {
    console.error("[worker] Failed to parse job message:", err.message);
    return;
  }

  const { jobId, walletAddress, network, includeEns } = job;
  console.info(`[worker] Received job ${jobId}: address=${walletAddress} chain=${network}`);

  try {
    await saveJobProgress(jobId, "queued");
    const result = await analyzeWallet({
      walletAddress,
      network,
      includeEns,
      onProgress: (stage) => saveJobProgress(jobId, stage).catch(() => {}),
    });
    await saveJobResult(jobId, { status: "SUCCESS", result });
    console.info(`[worker] Job ${jobId} completed`);
  } catch (err) {
    console.error(`[worker] Job ${jobId} failed: ${err.message}`);
    await saveJobResult(jobId, { status: "FAILURE", error: err.message }).catch(() => {});
  }
}

async function runInMemoryLoop() {
  console.info("[worker] Starting in-memory queue loop");
  while (_running) {
    if (inMemoryQueue.length === 0) {
      await new Promise((r) => setTimeout(r, IN_MEMORY_JOB_POLL_INTERVAL_MS || 500));
      continue;
    }
    const item = inMemoryQueue.shift();
    if (!item) continue;
    await handleRawMessage(item.payload);
  }
}

async function run() {
  const init = await initZmqPull();
  if (init.type === "zeromq") {
    _pull = init.pull;
    console.info("[worker] Ready — waiting for jobs on ZeroMQ pull socket");
    await runZmqLoop(_pull);
  } else {
    console.info("[worker] Ready — waiting for jobs in in-memory queue");
    await runInMemoryLoop();
  }
}

function shutdown() {
  console.info("[worker] Shutting down...");
  _running = false;
  try {
    if (_pull && typeof _pull.close === "function") _pull.close();
  } catch (err) {
    console.warn("[worker] Error closing pull socket:", err.message);
  }
  process.exit(0);
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

run().catch((err) => {
  console.error("[worker] Pull loop failed:", err.message);
  process.exit(1);
});
