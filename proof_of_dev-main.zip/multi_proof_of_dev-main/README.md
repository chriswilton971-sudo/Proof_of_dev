# Proof of Dev — On-Chain Developer Reputation

A full-stack web app that analyzes an Ethereum wallet's on-chain developer activity and generates a transparent, explainable reputation score. Optionally mint it as a soulbound (non-transferable) NFT on Sepolia or publish an EAS attestation.

---

## Features

- **Wallet connection** — MetaMask, Rabby, or WalletConnect via RainbowKit
- **Contract deployment detection** — Alchemy primary, Etherscan fallback
- **Verification check** — Etherscan source verification per contract (batched, rate-limit safe)
- **ENS resolution** — opt-in; name, avatar, URL, and GitHub handle
- **Reputation scoring** — deterministic engine with time multipliers and burst detection
- **Proof-of-Dev NFT** — soulbound ERC-721 on Sepolia, minted from the UI
- **EAS attestation** — delegated server signing; user submits on-chain
- **Downloadable report** — plain-text off-chain breakdown
- **Privacy-first** — ENS is opt-in; UI does not persist analysis data (optional MongoDB cache on the worker)

---

## Quick start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

That single command starts the analysis API, worker, and Next.js dashboard via `infra/scripts/dev.js`. This project is **local development only** — no production deploy path in the repo.

Copy `.env.example` to `.env.local` when you want live chain data, mint, or attest on Sepolia. **No API keys?** The app runs in **demo mode** — sample contracts and real scoring, no live Alchemy/Etherscan calls.

MongoDB is optional locally. Without it, job results stay in memory and indexed-cache features are skipped.

### Environment variables

See `.env.example` for the full list. Common keys:

| Variable | Purpose |
|----------|---------|
| `NEXT_PUBLIC_ALCHEMY_API_KEY` / `ALCHEMY_API_KEY` | Deployments + RPC |
| `ETHERSCAN_API_KEY` | Contract verification |
| `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID` | WalletConnect QR / mobile (optional for extension wallets) |
| `NEXT_PUBLIC_CONTRACT_ADDRESS` | ProofOfDev NFT on Sepolia |
| `NEXT_PUBLIC_EAS_SCHEMA_UID` | EAS schema UID |
| `ATTESTER_PRIVATE_KEY` | Server-side EAS attester (never expose to client) |
| `MONGO_URI` / `MONGO_DB` | Optional persistence |
| `WORKER_URL` | BFF → worker API (default `http://localhost:8000`) |
| `MOCK_CHAIN_DATA` | `1` = force demo, `0` = require real keys |

---

## Architecture

Analysis runs on the **analysis service** (`services/analysis/`), not inside the Next.js process.

```
Browser → POST /api/analyze (enqueue, 202 + jobId)
       → GET /api/analyze/[jobId] (poll with stage progress)
       → POST :8000/analyze → ZeroMQ → worker
       → chain-data + profile builder → AnalysisResponse
       → job result (memory + optional MongoDB)
       → BFF returns AnalysisResponse
```

| Process | Port | Role |
|---------|------|------|
| Next.js (web) | 3000 | UI + BFF |
| Analysis API | 8000 | Job enqueue + poll |
| ZeroMQ | 5000 | Queue transport |
| MongoDB | 27017 | Optional persistence + indexed cache |

### Data flow

1. UI enqueues analysis → worker API returns `jobId`.
2. Worker pulls job from ZeroMQ and runs stages: `queued` → `deployments` → `verification` → `ens` → `scoring` → `complete`.
3. Chain data comes from **indexed MongoDB cache** (if wallet was backfilled) or **live** Alchemy/Etherscan calls.
4. Worker builds a reputation profile with score, explanations, and warnings.
5. UI polls until complete (or partial / error).

### Specs (source of truth)

| Spec | Path |
|------|------|
| Scoring | `packages/scoring-spec/scoring.json` |
| Chain data | `packages/chain-data-spec/schema.json` |
| API | `openapi/analysis.yaml` |
| DB schema | `data/schema/mongodb.json` |

Scoring rules are implemented in `apps/web/lib/core/scoring.ts` (frontend) and `services/analysis/scoring.js` (worker). The dev launcher regenerates worker scoring from the spec on startup.

---

## How scoring works

| Signal | Points |
|--------|--------|
| Contract deployment | +5 (cap: 10) |
| Verified contract | +10 (cap: 10) |
| ENS name ownership | +2 |
| ENS metadata (avatar / url / github) | +3 each |

**Time weighting:** activity older than 30 days → 1.2×; recent activity → 0.8×.

**Anti-spam:** 3+ deployments within 7 days → extra 0.8× penalty on burst contracts.

| Score | Tier |
|-------|------|
| 0 | No Activity |
| 1–9 | Early Activity |
| 10–29 | Active Builder |
| 30–59 | Established |
| 60–99 | Prolific |
| 100+ | Extensive |

This profile reflects on-chain activity only — not developer skill or code quality.

---

## Indexed deployment cache

When a wallet is indexed in MongoDB, analysis reads cached deployments and verification before calling Alchemy/Etherscan. The results dashboard shows **indexed** vs **live** via the data source badge. Indexer and seed tooling live under `services/indexer/` and `scripts/` — not required for demo mode.

Schema: `data/schema/mongodb.json`.

---

## On-chain features

### ProofOfDev NFT (`contracts/ProofOfDev.sol`)

Soulbound ERC-721 on Sepolia — one mint per wallet. Metadata served from `/api/token/[id]`. Mint from the results dashboard after analyze. Set `NEXT_PUBLIC_CONTRACT_ADDRESS` in `.env.local` when a contract is deployed (Remix or project deploy scripts under `scripts/`).

### EAS attestation

Delegated server signing from `/api/attest`; the user's wallet submits on Sepolia. Set `NEXT_PUBLIC_EAS_SCHEMA_UID` and `ATTESTER_PRIVATE_KEY` in `.env.local`. Schema registration lives in `scripts/registerSchema.ts`.

---

## API reference

OpenAPI: `openapi/analysis.yaml`

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/analyze` | Enqueue analysis → `{ jobId, status: "PENDING" }` |
| GET | `/api/analyze/[jobId]` | Poll job (202 pending, 200/206 complete) |
| GET | `/api/profile/[address]` | Stored profile snapshot (needs MongoDB + prior analysis) |
| GET | `/api/token/[id]` | ERC-721 token metadata JSON |
| POST | `/api/attest` | Delegated EAS attestation payload |
| GET | `/api/worker-status` | Worker health check |

**Analyze request body:**

```json
{ "address": "0x...", "network": "mainnet"|"sepolia", "includeENS": false }
```

---

## Project structure

```
proof-of-dev/
├── apps/web/                 # Next.js UI + BFF (App Router)
├── packages/
│   ├── scoring-spec/         # Scoring weights, caps, tiers
│   └── chain-data-spec/      # Indexer entity schema
├── services/
│   ├── analysis/             # Worker API, queue, chain-data
│   └── indexer/              # Rust CLI → MongoDB
├── data/schema/              # MongoDB collections + indexes
├── infra/                    # local dev launcher (infra/scripts/dev.js)
├── openapi/                  # API contract
├── contracts/                # ProofOfDev.sol
├── scripts/                  # deploy, compile, seed, env check
└── tests/                    # scoring parity tests
```

---

## Tech stack

- **Next.js 16** (App Router) + **React 19** + **TypeScript**
- **Tailwind CSS 3**
- **RainbowKit v2 + Wagmi v2**
- **ethers.js v6**
- **Express + ZeroMQ + MongoDB** (analysis worker)
- **Rust** (indexer)
- **Solidity 0.8.20** (soulbound NFT)
- **EAS SDK** (attestations)

---

## Contributing

Submit a pull request against `main`. Keep changes focused. In the PR description, explain what you changed, why, and how you verified it on the dashboard.

---

## Disclaimer

This profile reflects on-chain activity only and does not guarantee developer skill or code quality. Data may be incomplete.
